#define BENCHMARK_DATA_DIR "/home/xuyou/.cpm_cache/croaring/fb2628131c81ddf8e7b8973f7a0db62a4aa5e082/benchmarks/realdata/"
#define TEST_DATA_DIR "/home/xuyou/.cpm_cache/croaring/fb2628131c81ddf8e7b8973f7a0db62a4aa5e082/tests/testdata/"
